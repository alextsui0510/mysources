Automated installation of software ruby depends on.

Usually there is no need to run requirements manually as it is part of ruby installation process.

## Usage

    rvm requirements ruby-2.1.0

See `rvm help autolibs` for details on how to control requirements behavior.
